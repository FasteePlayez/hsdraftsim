﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hearthstonecopybraskoprojekt
{
    internal class deck
    {
        public int pocetkaret { get; set; }
        public int common {  get; set; }
        public int rare { get; set; }
        public int epic { get; set; }
        public int legendary { get; set; }
        public string jmeno { get; set; }
    }
}
